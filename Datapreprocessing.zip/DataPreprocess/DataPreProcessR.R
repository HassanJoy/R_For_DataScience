dataset <-read.csv("DataSetR.csv")
dataset
set.seed(357)
dataset[dataset$Urban.Population...>0 & dataset$Urban.Population...< 50, ][, "type"] <- "small" 
dataset[dataset$Urban.Population...>50 & dataset$Urban.Population...<60, ][, "type"] <- "medium"
dataset[dataset$Urban.Population...>60 & dataset$Urban.Population...<70, ][, "type"] <- "large"
dataset[dataset$Urban.Population... >=70, ][, "type"] <- "extra large"
dataset
dataset$type = factor(dataset$type,levels = c('small', 'medium','large','extra large'), labels = c(0,1,2,3))
dataset
min_max_norm <- function(x) {
  (x - min(x)) / (max(x) - min(x))
}
dataset <- as.data.frame(lapply(dataset[2:4], min_max_norm))
dataset
dataset$Assault[is.na(dataset$Assault)] <- mean(dataset$Assault, na.rm = TRUE)
dataset